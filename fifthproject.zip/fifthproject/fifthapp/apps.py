from django.apps import AppConfig


class FifthappConfig(AppConfig):
    name = 'fifthapp'

from django.apps import AppConfig


class EighthappConfig(AppConfig):
    name = 'eighthapp'

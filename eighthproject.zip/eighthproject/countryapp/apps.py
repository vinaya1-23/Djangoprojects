from django.apps import AppConfig


class CountryappConfig(AppConfig):
    name = 'countryapp'
